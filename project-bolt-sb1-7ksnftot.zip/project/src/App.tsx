import React, { useState } from 'react';
import { Phone, MessageCircle, Calendar, Droplets, Users, Award, Globe, Heart, Languages, MapPin, Upload, X, Clock } from 'lucide-react';

function App() {
  // Base64 encoded image of Dr. Ranjeet Kumar
  const defaultProfileImage = https://ibb.co/LdZNvg7w